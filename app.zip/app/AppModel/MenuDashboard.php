<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;

class MenuDashboard extends Model
{
    protected $table ='menu_dashboard';
    
    protected $guarded = ['id'];
}