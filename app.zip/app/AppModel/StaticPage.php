<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;

class StaticPage extends Model
{
    protected $guarded = ['id'];
}