<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;
use DB;

class Pembelian_markup extends Model
{

}
