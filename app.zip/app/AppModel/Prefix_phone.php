<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;

class Prefix_phone extends Model
{
    protected $guarded = ['id'];
}
