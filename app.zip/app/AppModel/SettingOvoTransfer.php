<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;

class SettingOvoTransfer extends Model
{
    protected $table = 'settings_ovo_transfer';
    public $timestamps = false;
}