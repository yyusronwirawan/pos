<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;

class Rate extends Model
{
    protected $table = 'settings_rate';
    protected $primaryKey = 'id';
}