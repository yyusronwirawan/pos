<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;
use DB;

class Pengumuman extends Model
{
    protected $table = 'pengumuman';
    
}