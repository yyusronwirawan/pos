<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;

class Bank_swif extends Model
{
    protected $guarded = ['id'];
}
