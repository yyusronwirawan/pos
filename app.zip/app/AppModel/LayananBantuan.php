<?php

namespace App\AppModel;

use Illuminate\Database\Eloquent\Model;

class LayananBantuan extends Model
{
    protected $table      = 'layanan_bantuan';
    protected $primaryKey = "id";
	
}