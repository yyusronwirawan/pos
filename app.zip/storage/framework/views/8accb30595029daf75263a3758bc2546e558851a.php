

<?php $__env->startSection('profile'); ?>
<div class="box box-solid">
    <div class="box-header with-border">
        <i class="fa fa-user"></i>
        <h3 class="box-title">Kirim Testimonial</h3>
    </div>
    <div class="box-body">
        <form role="form" class="form-horizontal" action="<?php echo e(url('/member/testimonial')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="box-body">
                <div class="form-group<?php echo e($errors->has('rate') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Rate/Penilaian : </label>
                    <div class="col-sm-9">
                        <select name="rate" class="form-control">
                            <option value="">-- Pilih Penilaian/Bintang --</option>
                            <?php
                                for($i=1;$i<=5;$i++){
                            ?>
                            <option value="<?php echo e($i); ?>"><?php echo e($i); ?> (Bintang)</option>
                            <?php } ?>
                        </select>
                        <?php echo $errors->first('rate', '<p class="help-block"><small>:message</small></p>'); ?>

                    </div>
                </div>
                <div class="form-group<?php echo e($errors->has('review') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Review/Isi Testimonial : </label>
                    <div class="col-sm-9">
                        <textarea name="review" rows="4" class="form-control" placeholder="Masukkan pengalaman bertransaksi anda..."></textarea>
                        <?php echo $errors->first('review', '<p class="help-block"><small>:message</small></p>'); ?>

                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-9">
                        <button type="submit" class="submit btn  btn-primary btn-block">&nbsp;&nbsp;Kirim&nbsp;&nbsp;</button>
                    </div>
                </div>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('member.profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/firstpay/resources/views/member/profile/kirim-testimonial.blade.php ENDPATH**/ ?>