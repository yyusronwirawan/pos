
<?php $__env->startSection('meta'); ?>
<meta http-equiv="refresh" content="300">
<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs hidden-sm">
    <h1>Transaksi <small>Transfer Bank</small></h1>
    <ol class="breadcrumb">
        <li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
        <li><a href="#">Transaksi</a></li>
        <li class="active">Transfer Bank</li>
    </ol>
</section>
<section class="content">
    <div class="row hidden-xs hidden-sm">
        <div class="col-xs-12">
            <div class="box">
                <div class="box-header">
                   <h3 class="box-title">Mutasi Transfer Bank</h3>
                </div><!-- /.box-header -->
                <div class="box-body table-responsive">
                    <table id="DataTable"  class="table table-hover">
                      <thead>
                         <tr class="custom__text-green">
                            <th>No.</th>
                            <th>ID</th>
                            <th>Name</th>
                            <th>Penerima</th>
                            <th>Nominal</th>
                            <th>Code Bank</th>
                            <th>Bank</th>
                            <th>NO Rekening</th>
                            <th>Status</th>
                            <th>Tanggal</th>
                            <th>#</th>
                         </tr>
                      </thead>
                  <tbody>
                  </tbody>
               </table>
                </div><!-- /.box-body -->
            </div>
        </div><!-- /.box -->
    </div>
    <div class="row hidden-lg hidden-md">
        <div class="col-xs-12">
            <div class="box"> 
                <div class="box-header">
                    <h3 class="box-title">Mutasi Transfer Bank</h3>
                </div><!-- /.box-header -->
                <div class="box-body" style="padding: 0px">
                    <table class="table table-hover">
                        <?php $__currentLoopData = $antrianMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <tr>
                            <td>
                                <div><i class="fa fa-calendar"></i><small> <?php echo e(date("d M Y", strtotime($data->created_at))); ?></small></div>
                                <div style="font-size: 14px;font-weight: bold;">#<?php echo e($data->id); ?></div>
                                <div><?php echo e($data->name); ?></div>
                                <div>Penerima: <?php echo e($data->penerima); ?></div>
                            </td>
                            <td align="right" style="width:35%;">
                                <div><i class="fa fa-clock-o"></i><small> <?php echo e(date("H:i:s", strtotime($data->created_at))); ?></small></div>
                                <?php if($data->status == 0): ?>
                                <div><span class="label label-warning">PROSES</span></div>
                                <?php elseif($data->status == 1): ?>
                                <div><span class="label label-success">BERHASIL</span></div>
                                <?php elseif($data->status == 2): ?>
                                <div><span class="label label-danger">GAGAL</span></div>
                                <?php elseif($data->status == 3): ?>
                                <div><span class="label label-primary">REFUND</span></div>
                                <?php endif; ?>
                                <div style="margin-top:5px;">
                                    <!--<form method="POST" action="<?php echo e(url('/admin/transaksi/antrian/hapus', $data->id)); ?>" accept-charset="UTF-8">-->
                                    <!--    <input name="_method" type="hidden" value="DELETE">-->
                                    <!--    <input name="_token" type="hidden" value="<?php echo e(csrf_token()); ?>">-->
                                    <!--    <a href="<?php echo e(url('/admin/transaksi/antrian', $data->id)); ?>" class="btn-loading btn btn-primary btn-sm" style="padding: 2px 5px;font-size:10px;">Detail</a>-->
                                    <!--    <button class="btn btn-danger btn-sm" onclick="return confirm('Anda yakin akan menghapus data ?');" type="submit" style="padding: 2px 5px;font-size:10px;">Hapus</button>-->
                                    <!--</form>-->
                                    <a href="<?php echo e(url('/admin/transaksi/saldo-rekening', $data->id)); ?>" class="btn-loading label label-primary">DETAIL</a>
                                </div>
                            </td>
                        </tr>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </table>
                </div><!-- /.box-body -->
                <div class="box-footer" align="center" style="padding-top:13px;">
                   <?php echo $__env->make('pagination.default', ['paginator' => $antrianMobile], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
               </div>
            </div><!-- /.box -->
        </div>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    var table = $('#DataTable').DataTable({
        // deferRender: true,
        processing: true,
        serverSide: false,
        autoWidth: false,
        info: false,
        ajax:{
            url : "<?php echo e(url('/admin/transaksi/transfer-bank/datatables')); ?>",
        },
        columns:[
                  {data: null, width: "50px", sClass: "text-center", orderable: false},
                  {data: 'id', defaulContent: '-' },
                  // {data: 'trxid', defaulContent: '-' },
                  {data: 'name', defaulContent: '-'},
                  {data: 'penerima', defaulContent: '-'},
                  {data: 'nominal', defaulContent: '-', sClass: "text-right"},
                  {data: 'code_bank', defaulContent: '-'},
                  {data: 'jenis_bank', defaulContent: '-'},
                  {data: 'no_rekening', defaulContent: '-' },
                  {data: 'status', defaulContent: '-' },
                  {data: 'created_at', defaulContent: '-' },
                  {data: "action", defaultColumn: "-", orderable: false, searchable: false},
                ]
     });
     table.on( 'order.dt search.dt', function () {
        table.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
          cell.innerHTML = i+1;
        } );
     }).draw();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/agenpembayaran/agenpembayaran/resources/views/admin/transaksi/transfer-bank/index.blade.php ENDPATH**/ ?>