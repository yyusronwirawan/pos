

<?php $__env->startSection('profile'); ?>
<div class="box box-solid">
    <div class="box-header with-border">
        <i class="fa fa-university"></i>
        <h3 class="box-title">Alamat Bank</h3>
    </div>
    
    
    
    <div class="box-body">
        <?php if($sesi == 'CREATE'): ?>
        <form role="form" class="form-horizontal" action="<?php echo e(url('/member/tambah-rekening-bank')); ?>" method="post">
            <?php echo e(csrf_field()); ?>

            <div class="box-body">
                <div class="form-group<?php echo e($errors->has('nama_pemilik_bank') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Nama Pemilik Bank : </label>
                    <div class="col-sm-9">
                        <input type="text" name="nama_pemilik_bank" class="form-control" placeholder="Masukkan Nama Pemilik Bank">
                        <?php echo $errors->first('nama_pemilik_bank', '<p class="help-block"><small>:message</small></p>'); ?>

                    </div>
                </div>
                 <div class="form-group<?php echo e($errors->has('jenis_rek') ? ' has-error' : ''); ?>">
                      <label class="col-sm-3 control-label">Jenis Bank : </label>
                        <div class="col-sm-9">
                          <select class="form-control" id="jenis_rek" name="jenis_rek" style="width:100% !important";>
                          </select>
                         </div>
                    <?php echo $errors->first('jenis_rek', '<p class="help-block"><small>:message</small></p>'); ?>

                  </div>
                      
                <div class="form-group<?php echo e($errors->has('rek') ? ' has-error' : ''); ?>">
                    <label class="col-sm-3 control-label">Nomor Rekening : </label>
                    <div class="col-sm-9">
                        <input type="number" name="rek" class="form-control" placeholder="Masukkan Nomor Rekening">
                        <?php echo $errors->first('rek', '<p class="help-block"><small>:message</small></p>'); ?>

                    </div>
                </div>
                <div class="form-group">
                    <div class="col-sm-offset-3 col-sm-9">
                        <button type="submit" class="submit btn btn-primary btn-block">&nbsp;&nbsp;Simpan&nbsp;&nbsp;</button>
                    </div>
                </div>
            </div>
        </form>
        <?php endif; ?>
        <?php if($sesi == 'VIEW'): ?>
                <table class="table" style="font-size:14px;">
                     <tr>
                        <td>Nama Pemilik</td>
                        <td>:</td>
                        <td><?php echo e($cek->nama_pemilik_bank); ?></td>
                     </tr>
                     <tr>
                        <td>Jenis Bank</td>
                        <td>:</td>
                        <td><?php echo e($cek->name); ?> / Kode Bank : <?php echo e($cek->code); ?></td>
                     </tr>
                     <tr>
                        <td>Nomor Rekening</td>
                        <td>:</td>
                        <td><?php echo e($cek->no_rekening); ?></td>
                     </tr>
                  </table>
        <?php endif; ?>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    
    $('#jenis_rek').select2({
        placeholder: "Pilih Jenis Bank",
        ajax: {
            url: "<?php echo e(route('get.bank.code')); ?>",            
            data: function(params){
                 return {
                     q: params.term
                 };
             },
            processResults: function(data){
                $('#pilih_member').empty();
                return {
                    results : data,
                }
            }

        }
    });
    
   // Select your input element.
   var number = document.getElementById('number');

   // Listen for input event on numInput.
   number.onkeydown = function(e) {
       if(!((e.keyCode > 95 && e.keyCode < 106)
         || (e.keyCode > 47 && e.keyCode < 58) 
         || e.keyCode == 8)) {
           return false;
       }
   }
   
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('member.profile.index', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/firstpay/resources/views/member/profile/rekening.blade.php ENDPATH**/ ?>