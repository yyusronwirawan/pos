

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs">
	<h1>Tagihan <small>Pembayaran</small></h1>
   <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/member')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
    	<li class="active">Tagihan Pembayaran</li>
   </ol>
   </section>
   <section class="content">
      <div class="row hidden-xs hidden-sm">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">Tagihan Pembayaran</h3>
               </div><!-- /.box-header -->
               <div class="box-body table-responsive">
               <table id="DataTable"  class="table table-hover">
                  <thead>
                     <tr class="custom__text-green">
                        <th>No.</th>
                        <th>Produk</th>
                        <th>Nomor / ID Pelanggan</th>
                        <th>Nama</th>
                        <th>Periode</th>
                        <th>Via</th>
                        <th>Status</th>
                        <th>Expired</th>
                        <th>Tanggal</th>
                        <th>#</th>
                     </tr>
                  </thead>
                  <tbody>
                  </tbody>
               </table>
            </div><!-- /.box-body -->
         </div><!-- /.box -->
      </div>
   </div>
   <div class="row hidden-lg hidden-md">
      <div class="col-xs-12">
         <div class="box">
            <div class="box-header">
               <h3 class="box-title"><a href="<?php echo e(url('/member')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left custom__text-green" style="margin-right:10px;"></i></a>Tagihan Pembayaran</h3>
            </div><!-- /.box-header -->
            <div class="box-body" style="padding: 0px">
               <table class="table table-hover">
                  <?php if($tagihanMobile->count() > 0): ?>
                  <?php $__currentLoopData = $tagihanMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td>
                            <a href="<?php echo e(url('/member/tagihan-pembayaran', $data->id)); ?>" class="btn-loading" style="color: #464646">
                                <div style="font-size:12px;"><i class="fa fa-calendar"></i><small> <?php echo e($data->created_at); ?></small></div>
                                <div><small>ID : #<?php echo e($data->tagihan_id); ?></small></div>
                                <div style="font-size: 14px;font-weight: bold;"><?php echo e($data->product_name); ?></div>
                                <div><?php echo e($data->no_pelanggan); ?></div>
                                <div><code><?php echo e($data->via); ?></code></div>
                            </a>
                        </td>
                        <td align="right" style="width:40%;">
                            <a href="<?php echo e(url('/member/tagihan-pembayaran', $data->id)); ?>" class="btn-loading" style="color: #464646">
                                <div style="font-size:12px;"><i class="fa fa-calendar"></i><small> <?php echo e($data->updated_at); ?></small></div>
                                <div style="text-transform: capitalize;"><?php echo e($data->nama); ?></div>
                                <div>Rp <?php echo e(number_format($data->jumlah_bayar, 0, '.', '.')); ?></div>
                                <?php if($data->status == 0): ?>
                                <div><label class="label label-warning">MENUNGGU</label></div>
                                <?php elseif($data->status == 1): ?>
                                <div><label class="label label-primary">PROSES</label></div>
                                <?php elseif($data->status == 2): ?>
                                <div><span class="label label-success">BERHASIL</span></div>
                                <?php else: ?>
                                <div><span class="label label-danger">GAGAL</span></div>
                                <?php endif; ?>
                            </a>
                         <div>
                            <?php if($data->status == 0): ?>
                            <a href="<?php echo e(url('/member/tagihan-pembayaran', $data->id)); ?>" class="btn-loading label label-primary">Bayar</a>
                            <?php elseif($data->status == 1): ?>
                            <a href="<?php echo e(url('/member/tagihan-pembayaran', $data->id)); ?>" class="btn-loading label label-primary">Detail</a>
                            <?php elseif($data->status == 2): ?>
                            <a href="<?php echo e(url('/member/tagihan-pembayaran', $data->id)); ?>" class="btn-loading label label-primary">Detail</a>
                            <?php else: ?>
                            <a href="<?php echo e(url('/member/tagihan-pembayaran', $data->id)); ?>" class="btn-loading label label-primary">Detail</a>
                            <?php endif; ?>
                          </div>
                            
                        </td>
                    </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <tr>
                      <td colspan="2" style="text-align:center;font-style:italic;">Tagihan Pembayaran belum tersedia</td>
                  </tr>
                  <?php endif; ?>
               </table>
            </div><!-- /.box-body -->
            <div class="box-footer" align="center" style="padding-top:13px;">
               <?php echo $__env->make('pagination.default', ['paginator' => $tagihanMobile], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
         </div><!-- /.box -->
     </div>
   </div>
</section>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    var table = $('#DataTable').DataTable({
        deferRender: true,
        processing: true,
        serverSide: true,
        autoWidth: true,
        autoHight: true,
        info: false,
        ajax:{
            url : "<?php echo e(route('get.tagihan-pembayaran.datatables')); ?>",
            dataType: "json",
            type: "POST",
            data:{ _token: "<?php echo e(csrf_token()); ?>"}
        },
        columns:[
                  {data: 'no', sClass: "text-left", orderable: false},
                  {data: 'product_name', defaulContent: '-' },
                  {data: 'no_pelanggan', defaulContent: '-' },
                  {data: 'nama', defaulContent: '-'},
                  {data: 'periode', defaulContent: '-' },
                  {data: 'via', defaulContent: '-' },
                  {data: 'status', defaulContent: '-' },
                  {data: 'expired', defaulContent: '-' },
                  {data: 'created_at', defaulContent: '-' },
                  {data: "action", defaultColumn: "-", orderable: false, searchable: false},
                ]
     });
     table.on( 'order.dt search.dt', function () {
        table.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
          cell.innerHTML = i+1;
        } );
     }).draw();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/firztpay/firztpay/resources/views/member/tagihan/index.blade.php ENDPATH**/ ?>