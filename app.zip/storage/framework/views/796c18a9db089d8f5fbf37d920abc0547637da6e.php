

<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>Setting <small>Kurs</small></h1>
   <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="Javascript:;">Pengaturan</a></li>
      <li><a href="<?php echo e(route('setting.kurs.index')); ?>" class="btn-loading">Kurs</a></li>
      <li class="active">Minimal Deposit</li>
   </ol>
   </section>
   <section class="content">
      <div class="row">
         <div class="col-md-6">
            <div class="box box-green">
               <div class="box-header">
                 <h3 class="box-title"><a href="<?php echo e(route('bank.index')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Set Kurs</h3>
               </div>
               <form role="form" action="<?php echo e(route('setting.kurs.update')); ?>" method="post">
               <input name="_method" type="hidden" value="PATCH">
               <?php echo e(csrf_field()); ?>

                    <div class="box-body">
                        <?php $__currentLoopData = $kurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group<?php echo e($errors->has($k->name) ? ' has-error' : ''); ?>">
                                <label><?php echo e($k->name); ?> : </label>
                                <input type="text" class="form-control" name="<?php echo e($k->name); ?>" id="<?php echo e($k->name); ?>" value="<?php echo e(number_format($k->value, 0, '.', '.')); ?>"  placeholder="">
                                <?php echo $errors->first($k->name, '<p class="help-block"><small>:message</small></p>'); ?>

                            </div>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  </div>

                  <div class="box-footer">
                     <button type="reset" class="btn btn-default">Reset</button>
                     <button type="submit" class="submit btn btn-primary">Simpan</button>
                  </div>
               </form>
            </div>
         </div>
      </div>
   </section>
</section>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
<script type="text/javascript">

$(document).ready(function() {

    function autoMoneyFormat(b){
        var _minus = false;
        if (b<0) _minus = true;
        b = b.toString();
        b=b.replace(".","");
        b=b.replace("-","");
        c = "";
        panjang = b.length;
        j = 0;
        for (i = panjang; i > 0; i--){
        j = j + 1;
        if (((j % 3) == 1) && (j != 1)){
        c = b.substr(i-1,1) + "." + c;
        } else {
        c = b.substr(i-1,1) + c;
        }
        }
        if (_minus) c = "-" + c ;
        return c;
    }

      function price_to_number(v){
      if(!v){return 0;}
          v=v.split('.').join('');
          v=v.split(',').join('');
      return Number(v.replace(/[^0-9.]/g, ""));
      }
      
      function number_to_price(v){
      if(v==0){return '0,00';}
          v=parseFloat(v);
          // v=v.toFixed(2).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
          v=v.toFixed(0).replace(/(\d)(?=(\d\d\d)+(?!\d))/g, "$1,");
          v=v.split('.').join('*').split(',').join('.').split('*').join(',');
      return v;
      }
      
      function formatNumber (num) {
        return num.toString().replace(/(\d)(?=(\d{3})+(?!\d))/g, "$1.")
      }
    
    <?php $__currentLoopData = $kurs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $k): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
        $('#<?php echo e($k->name); ?>').keyup(function(){
            var <?php echo e($k->name); ?> = parseInt(price_to_number($('#<?php echo e($k->name); ?>').val()));
            var autoMoney = autoMoneyFormat(<?php echo e($k->name); ?>);
            $('#<?php echo e($k->name); ?>').val(autoMoney);
        });
    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
});

</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/firstpay/resources/views/admin/pengaturan/kurs/index.blade.php ENDPATH**/ ?>