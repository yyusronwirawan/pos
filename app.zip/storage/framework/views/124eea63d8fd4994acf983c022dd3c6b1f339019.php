

<?php $__env->startSection('content'); ?>
<section class="content-header hidden-xs">
	<h1>Depsoit <small>Mutasi Saldo</small></h1>
   <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/member')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
    	<li><a href="Javascript:;">Deposit</a></li>
    	<li class="active">Mutasi Saldo</li>
   </ol>
   </section>
   <section class="content">
      <div class="row hidden-xs hidden-sm">
         <div class="col-xs-12">
            <div class="box">
               <div class="box-header">
                  <h3 class="box-title">Mutasi Saldo</h3>
               </div><!-- /.box-header -->
               <div class="box-body table-responsive">
               <table id="DataTable"  class="table table-hover">
                  <thead>
                     <tr class="custom__text-green">
                        <th>No.</th>
                        <th>Tanggal</th>
                        <th>Type</th>
                        <th>Jumlah</th>
                        <th>Saldo</th>
                        <th>Trxid</th>
                        <th>Keterangan</th>
                     </tr>
                  </thead>
                  <tbody>
                  </tbody>
               </table>
            </div><!-- /.box-body -->
         </div><!-- /.box -->
      </div>
   </div>
   <div class="row hidden-lg hidden-md">
      <div class="col-xs-12">
         <div class="box">
            <div class="box-header">
               <h3 class="box-title"><a href="<?php echo e(url('/member')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Mutasi Saldo</h3>
            </div><!-- /.box-header -->
            <div class="box-body" style="padding: 0px">
               <table class="table table-hover">
                  <?php if($mutasiMobile->count() > 0): ?>
                  <?php $__currentLoopData = $mutasiMobile; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $data): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                  <tr>
                     <td>
                       <div><i class="fa fa-calendar"></i> <small><?php echo e(date("d M Y", strtotime($data->created_at))); ?></small></div>
                       <div style="font-size: 12px;font-weight: bold;"><?php echo e($data->note); ?></div>
                       <div style="color:grey;font-style: italic;">Sisa Saldo : Rp <?php echo e(number_format($data->saldo, 0, '.', '.')); ?></div>
                     </td>
                     <td align="right" style="width:35%;">
                        <div><i class="fa fa-clock-o"></i> <small><?php echo e(date("H:i:s", strtotime($data->created_at))); ?></small></div>
                        <?php if($data->type == 'debit'): ?>
                        <div style="font-weight: bold;" class="text-danger"> - Rp <?php echo e(number_format($data->nominal, 0, '.', '.')); ?></div>
                        <?php else: ?>
                        <div style="font-weight: bold;" class="text-success">Rp <?php echo e(number_format($data->nominal, 0, '.', '.')); ?></div>
                        <?php endif; ?>
                     </td>
                  </tr>
                  <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                  <?php else: ?>
                  <tr>
                      <td colspan="2" style="text-align:center;font-style:italic;">Mutasi belum tersedia</td>
                  </tr>
                  <?php endif; ?>
               </table>
            </div><!-- /.box-body -->
            <div class="box-footer" align="center" style="padding-top:13px;">
                <?php echo $__env->make('pagination.default', ['paginator' => $mutasiMobile], \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
            </div>
         </div><!-- /.box -->
     </div>
   </div>
</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
$(document).ready(function() {
    var table = $('#DataTable').DataTable({
        deferRender: true,
        processing: true,
        serverSide: true,
        autoWidth: true,
        autoHight: true,
        info: false,
        ajax:{
            url : "<?php echo e(route('get.mutasiSaldo.datatables')); ?>",
            dataType: "json",
            type: "POST",
            data:{ _token: "<?php echo e(csrf_token()); ?>"}
        },
        columns:[
                  {data: 'no', sClass: "text-left", orderable: false},
                  {data: 'created_at', defaulContent: '-' },
                  {data: 'type', defaulContent: '-' },
                  {data: 'nominal', defaulContent: '-' , sClass: "text-right"},
                  {data: 'saldo', defaulContent: '-' , sClass: "text-right"},
                  {data: 'trxid', defaulContent: '-' },
                  {data: 'note', defaulContent: '-' },
                ]
     });
     table.on( 'order.dt search.dt', function () {
        table.column(0, {search:'applied', order:'applied'}).nodes().each( function (cell, i) {
          cell.innerHTML = i+1;
        } );
     }).draw();
});
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.member', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/tripayco/system_external/firstpay/resources/views/member/deposit/mutasi-saldo/index.blade.php ENDPATH**/ ?>