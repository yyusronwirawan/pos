<?php $__env->startSection('content'); ?>
<section class="content-header">
	<h1>Produk <small>Kategori</small></h1>
   <ol class="breadcrumb">
    	<li><a href="<?php echo e(url('/admin')); ?>" class="btn-loading"><i class="fa fa-dashboard"></i> Home</a></li>
      <li><a href="Javascript:;">Pengaturan</a></li>
      <li><a href="<?php echo e(route('bank.index')); ?>" class="btn-loading">Data Bank</a></li>
      <li class="active">Ubah Data Bank</li>
   </ol>
   </section>
   <section class="content">
      <div class="row">
         <div class="col-md-6">
            <div class="box box-primary">
               <div class="box-header">
                 <h3 class="box-title"><a href="<?php echo e(route('bank.index')); ?>" class="hidden-lg btn-loading"><i class="fa fa-arrow-left" style="margin-right:10px;"></i></a>Ubah Data Bank</h3>
               </div>
               <form role="form" action="<?php echo e(route('bank.update', $banks->id)); ?>" method="post" accept-charset="UTF-8" enctype="multipart/form-data">
               <input name="_method" type="hidden" value="PATCH">
               <?php echo e(csrf_field()); ?>

                  <div class="box-body">
                     <div class="form-group<?php echo e($errors->has('nama_bank') ? ' has-error' : ''); ?>">
                        <label>Nama Bank : </label>
                        <input type="text" class="form-control" name="nama_bank" value="<?php echo e($banks->nama_bank); ?>"  placeholder="Masukkan Nama Bank">
                        <?php echo $errors->first('nama_bank', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('atas_nama') ? ' has-error' : ''); ?>">
                        <label>Nama Pemilik : </label>
                        <input type="text" class="form-control" name="atas_nama" value="<?php echo e($banks->atas_nama); ?>"  placeholder="Masukkan Nama Pemilik Rekening">
                         <?php echo $errors->first('atas_nama', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('no_rek') ? ' has-error' : ''); ?>">
                        <label>Nomor Rekening : </label>
                        <input type="text" class="form-control" name="no_rek" value="<?php echo e($banks->no_rek); ?>"  placeholder="Masukkan Nomor Rekening Rekening">
                         <?php echo $errors->first('no_rek', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                     <div class="form-group<?php echo e($errors->has('code') ? ' has-error' : ''); ?>">
                        <label>Kode Bank : </label>
                        <input type="text" class="form-control" name="code" value="<?php echo e($banks->code); ?>"  placeholder="Masukkan Kode Bank">
                         <?php echo $errors->first('code', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                    
                     <div class="form-group<?php echo e($errors->has('image') ? ' has-error' : ''); ?>">
                        <label>Logo / Gambar Bank : </label>
                        <input type="file" name="image" accept="image/*">
                        <img src="<?php echo e(asset('img/banks/'.$banks->image)); ?>" class="img-thumbnail" style="height: 40px;margin-top: 5px;"  alt="<?php echo e($banks->nama_bank); ?>">
                         <?php echo $errors->first('image', '<p class="help-block"><small>:message</small></p>'); ?>

                         <button type="button" id="btn-batal" onclick="batal()" class=" btn btn-primary none">Batal Tambah</button>
                        </div>
                     <div class="form-group<?php echo e($errors->has('nama_provider') ? ' has-error' : ''); ?>" id="provider">
                        <label>Provider : </label>
                        <select name="provider"  class="form-control" value="<?php echo e($banks->provider_id); ?>">
                           <?php $__currentLoopData = $provider; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option <?php echo e($banks->provider_id ==  $item->id ? 'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->name); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <!--<button type="button" id="btn-tambah" onclick="tambah()" class=" btn btn-primary">Tambah provider +</button>-->
                     </div>
                     <div class="form-group<?php echo e($errors->has('nama_provider') ? ' has-error' : ''); ?>" id="provider">
                        <label>Bank Kategori : </label>
                        <select name="bank_kategori_id"  class="form-control">
                           <?php $__currentLoopData = $bank_kategori; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                           <option <?php echo e($banks->bank_kategori_id ==  $item->id ? 'selected':''); ?> value="<?php echo e($item->id); ?>"><?php echo e($item->paymethod); ?></option>
                           <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>
                        <!--<button type="button" id="btn-tambah" onclick="tambah()" class=" btn btn-primary">Tambah provider +</button>-->
                     </div>
                     <!--<div class="form-group<?php echo e($errors->has('tambah_provider') ? 'has-error' : ''); ?> none" id="tambah_provider">-->
                     <!--   <label for="tambah_provider">Provider : </label>-->
                     <!--   <input type="text" class="form-control" name="tambah_provider"  placeholder="Nama Provider">-->
                     <!--   <?php echo $errors->first('tambah_provider', '<p class="help-block"><small>:message</small></p>'); ?>-->
                     <!--</div>-->
                     <!--<div class="form-group<?php echo e($errors->has('merchant_code') ? ' has-error' : ''); ?> none" id="merchant_code">-->
                     <!--   <label>Merchant Code : </label>-->
                     <!--   <input type="text" class="form-control" name="merchant_code" value="<?php echo e(old('merchant_code')); ?>"  placeholder="Masukkan Merchant Code">-->
                     <!--    <?php echo $errors->first('merchant_code', '<p class="help-block"><small>:message</small></p>'); ?>-->
                     <!--</div>-->
                     <!--<div class="form-group<?php echo e($errors->has('api_key') ? ' has-error' : ''); ?> none" id="api_key">-->
                     <!--   <label>Api Key : </label>-->
                     <!--   <input type="text" class="form-control" name="api_key" value="<?php echo e(old('api_key')); ?>"  placeholder="Masukkan Api Key">-->
                     <!--    <?php echo $errors->first('api_key', '<p class="help-block"><small>:message</small></p>'); ?>-->
                     <!--</div>-->
                     <!--<div class="form-group<?php echo e($errors->has('api_signature') ? ' has-error' : ''); ?> none" id="api_signature">-->
                     <!--   <label>Api Signature : </label>-->
                     <!--   <input type="text" class="form-control" name="api_signature" value="<?php echo e(old('Api Signature')); ?>"  placeholder="Masukkan Api Signature">-->
                     <!--    <?php echo $errors->first('api_signature', '<p class="help-block"><small>:message</small></p>'); ?>-->
                     <!--</div>-->
                     <!--<div class="form-group<?php echo e($errors->has('private_key') ? ' has-error' : ''); ?> none" id="private_key">-->
                     <!--   <label>Private Key : </label>-->
                     <!--   <input type="text" class="form-control" name="private_key" value="<?php echo e(old('private_key')); ?>"  placeholder="Masukkan Private Key">-->
                     <!--    <?php echo $errors->first('private_key', '<p class="help-block"><small>:message</small></p>'); ?>-->
                     <!--</div>-->
                     <!--<div class="form-group<?php echo e($errors->has('ipn_secret') ? ' has-error' : ''); ?> none" id="ipn_secret">-->
                     <!--   <label>IPN Secret : </label>-->
                     <!--   <input type="text" class="form-control" name="ipn_secret" value="<?php echo e(old('ipn_secret')); ?>"  placeholder="Masukkan IPN Secret">-->
                     <!--    <?php echo $errors->first('ipn_secret', '<p class="help-block"><small>:message</small></p>'); ?>-->
                     <!--</div>-->
                     <!--<div class="form-group<?php echo e($errors->has('public_key') ? ' has-error' : ''); ?> none" id="public_key">-->
                     <!--   <label>Public Key : </label>-->
                     <!--   <input type="text" class="form-control" name="public_key" value="<?php echo e(old('public_key')); ?>"  placeholder="Masukkan Public Key">-->
                     <!--    <?php echo $errors->first('public_key', '<p class="help-block"><small>:message</small></p>'); ?>-->
                     <!--</div>-->
                     <div class="form-group<?php echo e($errors->has('logo') ? ' has-error' : ''); ?>" id="logo">
                        <label>Logo / Gambar Provider : </label>
                        <input type="file" name="logo" accept="image/*">
                         <?php echo $errors->first('logo', '<p class="help-block"><small>:message</small></p>'); ?>

                     </div>
                    
                    
                  </div>

                  <div class="box-footer">
                     <button type="reset" class="btn btn-default">Reset</button>
                     <button type="submit" class="submit btn btn-primary">Simpan</button>
                  </div>
               </form>
            </div>
         </div>
         <div class="col-md-6">
            <div class="box box-solid box-penjelasan">
               <div class="box-header with-border">
                    <i class="fa fa-text-width"></i>
                    <h3 class="box-title">Penjelasan Form</h3>
                    <div class="box-tools pull-right box-minus" style="display:none;">
                        <button class="btn btn-box-tool" data-widget="collapse"><i class="fa fa-plus"></i></button>
                    </div>
               </div><!-- /.box-header -->
               <div class="box-body">
                  <dl>
                     <dt>Nama Bank</dt>
                     <dd style="font-size: 12px;">Isi dengan Nama Bank (contoh : BRI, BNI, BCA, Dll)</dd>
                     <dt>Nama Pemilik</dt>
                     <dd style="font-size: 12px;">Isi dengan Nama Pemilik Rekening yang tercantum dalam buku rekening.</dd>
                     <dt>Nomor Rekening</dt>
                     <dd style="font-size: 12px;">Isi dengan Nomor Rekening Bank.</dd>
                     <dt>Logo / Gambar Bank</dt>
                     <dd style="font-size: 12px;">Isi dengan Logo / Gambar dari Bank</dd>
                     <dt>Note!!:</dt>
                     <dt>Hanya ganti provider apabila memang perlu!</dt>
                     
                  </dl>
               </div><!-- /.box-body -->
            </div><!-- /.box -->
         </div>
      </div>
   </section>

</section>
<?php $__env->stopSection(); ?>
<?php $__env->startSection('js'); ?>
<script>
   function tambah(){
      $('#provider').addClass('none');
      $('#tambah_provider').removeClass('none');
      $('#logo_provider').addClass('none');
      $('#btn-tambah').addClass('none');
      $('#btn-batal').removeClass('none');
      $('#logo').removeClass('none');
      $('#api_key').removeClass('none');
      $('#api_signature').removeClass('none');
      $('#private_key').removeClass('none');
      $('#public_key').removeClass('none');
      $('#ipn_secret').removeClass('none');
      $('#merchant_code').removeClass('none');
      
   }
   function batal(){
      $('#provider').removeClass('none');
      $('#tambah_provider').addClass('none');
      $('#logo_provider').removeClass('none');
      $('#btn-tambah').removeClass('none');
      $('#btn-batal').addClass('none');
      $('#logo').addClass('none');
      $('#api_key').addClass('none');
      $('#api_signature').addClass('none');
      $('#private_key').addClass('none');
      $('#public_key').addClass('none');
      $('#ipn_secret').addClass('none');
      $('#merchant_code').addClass('none');
   }
</script>
<?php $__env->stopSection(); ?>
<?php echo $__env->make('layouts.admin', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH /home/firztpay/firztpay/resources/views/admin/pengaturan/bank/edit.blade.php ENDPATH**/ ?>